# SS-30 Music Board

This is a rough recreation of the Newtech Computer Systems model 68 music board.  No atttempt
was made to make it look exactly like the original, but it is 100% compatible and uses the
same components as the original.

